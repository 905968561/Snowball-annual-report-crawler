# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import redis
import pymysql as py

from gupiao.items import SH_Link, SZ_Link, CYB_Link, Ttt, Lrb_Info


# https: // stock.xueqiu.com / v5 / stock / finance / cn / income.json?symbol = SZ300122 & type = Q4 & is_detail = true & count = 5 & timestamp =
# https: // stock.xueqiu.com / v5 / stock / finance / cn / income.json?symbol = SH601318 & type = Q4 & is_detail = true & count = 5 & timestamp =
# https: // stock.xueqiu.com / v5 / stock / finance / cn / balance.json?symbol = SZ300820 & type = Q4 & is_detail = true & count = 5 & timestamp =
# https: // stock.xueqiu.com / v5 / stock / finance / cn / cash_flow.json?symbol = SZ300820 & type = Q4 & is_detail = true & count = 5 & timestamp =

# 沪市
def push_lrb_sh(redis_conn, item):
    redis_conn.rpush("job:lrb_link", "https://stock.xueqiu.com/v5/stock/finance/cn/income.json?symbol=SH" + item[
        "sh_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


def push_zcfzb_sh(redis_conn, item):
    redis_conn.rpush("job:zcfzb_link", "https://stock.xueqiu.com/v5/stock/finance/cn/balance.json?symbol=SH" + item[
        "sh_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


def push_xjllb_sh(redis_conn, item):
    redis_conn.rpush("job:xjllb_link", "https://stock.xueqiu.com/v5/stock/finance/cn/cash_flow.json?symbol=SH" + item[
        "sh_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


# 深市
def push_lrb_sz(redis_conn, item):
    redis_conn.rpush("job:lrb_link", "https://stock.xueqiu.com/v5/stock/finance/cn/income.json?symbol=SZ" + item[
        "sz_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


def push_zcfzb_sz(redis_conn, item):
    redis_conn.rpush("job:zcfzb_link", "https://stock.xueqiu.com/v5/stock/finance/cn/balance.json?symbol=SZ" + item[
        "sz_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


def push_xjllb_sz(redis_conn, item):
    redis_conn.rpush("job:xjllb_link", "https://stock.xueqiu.com/v5/stock/finance/cn/cash_flow.json?symbol=SZ" + item[
        "sz_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


# 创业板（深市）
def push_lrb_cyb(redis_conn, item):
    redis_conn.rpush("job:lrb_lin", "https://stock.xueqiu.com/v5/stock/finance/cn/income.json?symbol=SZ" + item[
        "cyb_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


def push_zcfzb_cyb(redis_conn, item):
    redis_conn.rpush("job:zcfzb_lin", "https://stock.xueqiu.com/v5/stock/finance/cn/balance.json?symbol=SZ" + item[
        "cyb_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


def push_xjllb_cyb(redis_conn, item):
    redis_conn.rpush("job:xjllb_lin", "https://stock.xueqiu.com/v5/stock/finance/cn/cash_flow.json?symbol=SZ" + item[
        "cyb_code"] + "&type=Q4&is_detail=true&count=5&timestamp=")


class GupiaoPipeline:
    def __init__(self):
        pool = redis.ConnectionPool(host="localhost", port=6379, max_connections=1024)
        # 创建连接对象
        conn = redis.Redis(connection_pool=pool)
        self.redis_conn = conn

    def process_item(self, item, spider):
        # link 初始化
        if isinstance(item, SH_Link):
            push_lrb_sh(self.redis_conn, item)
            push_zcfzb_sh(self.redis_conn, item)
            push_xjllb_sh(self.redis_conn, item)
        elif isinstance(item, SZ_Link):
            push_lrb_sz(self.redis_conn, item)
            push_zcfzb_sz(self.redis_conn, item)
            push_xjllb_sz(self.redis_conn, item)
        elif isinstance(item, CYB_Link):
            push_lrb_cyb(self.redis_conn, item)
            push_zcfzb_cyb(self.redis_conn, item)
            push_xjllb_cyb(self.redis_conn, item)
        elif isinstance(item, Lrb_Info):
            conn = py.connect("localhost", "root", "root", "gupiao")
            cursor = conn.cursor()
            # create_table = '''
            #                     '''
            # cursor.execute(create_table)
            insert = '''
                                insert into t_income_statement(id,i_year,cost_of_sales,operating_costs,operating_profits,operating_income,netprofit
                                ) values
                                ('%s','%s','%s','%s','%s','%s','%s');
                                ''' % (
            item['name'], item['year'], item['cost_of_sales'], item['operating_costs'], item['operating_profits'],
            item['operating_income'], item['netprofit'])
            cursor.execute(insert)
            conn.commit()
            cursor.close()
            conn.close()
