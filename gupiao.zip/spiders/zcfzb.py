import json

from scrapy_redis.spiders import RedisSpider, RedisCrawlSpider

from gupiao.items import Zcfzb_Info


class LRB(RedisCrawlSpider):
    name = 'info_zcfzb'
    redis_key = "job:zcfzb_lin"

    def parse(self, response):
        info = json.loads(response.text)
        data = info['data']
        name = data['quote_name']  # 公司名称
        for i in range(5):
            data_year = data['list'][i]
            year = data_year['report_name']
            total_liab = data_year['total_liab'][0]  # 负债合计
            inventory = data_year['inventory'][0]  # 存货
            account_receivable = data_year['account_receivable'][0]  # 应收账款
            shares = data_year['shares'][0]  # 实收资本
            total_quity_atsopc = data_year['total_quity_atsopc'][0]  # 所有者权益
            total_current_assets = data_year['total_current_assets'][0]  # 流动资产合计
            total_assets = data_year['total_assets'][0]  # 资产总计
            total_current_liab = data_year['total_current_liab'][0]  # 流动负债合计
            zcfzb_info = Zcfzb_Info()
            zcfzb_info['name'] = name
            zcfzb_info['year'] = year
            zcfzb_info['total_liab'] = total_liab
            zcfzb_info['inventory'] = inventory
            zcfzb_info['account_receivable'] = account_receivable
            zcfzb_info['shares'] = shares
            zcfzb_info['total_quity_atsopc'] = total_quity_atsopc
            zcfzb_info['total_current_assets'] = total_current_assets
            zcfzb_info['total_assets'] = total_assets
            zcfzb_info['total_current_liab'] = total_current_liab
            yield zcfzb_info
