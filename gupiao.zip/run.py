from scrapy.cmdline import execute

# execute("scrapy crawl cyb_link".split(" "))
# execute("scrapy crawl sh_link".split(" "))
execute("scrapy crawl info_lrb".split(" "))